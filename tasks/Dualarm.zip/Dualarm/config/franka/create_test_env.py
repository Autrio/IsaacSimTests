

import argparse

from omni.isaac.lab.app import AppLauncher

# add argparse arguments
parser = argparse.ArgumentParser(description="Tutorial on using the differential IK controller.")
parser.add_argument("--robot", type=str, default="franka_panda", help="Name of the robot.")
parser.add_argument("--num_envs", type=int, default=1, help="Number of environments to spawn.")
# append AppLauncher cli args
AppLauncher.add_app_launcher_args(parser)
# parse the arguments
args_cli = parser.parse_args()

# launch omniverse app
app_launcher = AppLauncher(args_cli)
simulation_app = app_launcher.app

"""Rest everything follows."""

import torch

import omni.isaac.lab.sim as sim_utils
from omni.isaac.lab.assets import AssetBaseCfg
from omni.isaac.lab.controllers import DifferentialIKController, DifferentialIKControllerCfg
from omni.isaac.lab.managers import SceneEntityCfg
from omni.isaac.lab.markers import VisualizationMarkers
from omni.isaac.lab.markers.config import FRAME_MARKER_CFG
from omni.isaac.lab.scene import InteractiveScene, InteractiveSceneCfg
from omni.isaac.lab.utils import configclass
from omni.isaac.lab.utils.assets import ISAAC_NUCLEUS_DIR
from omni.isaac.lab.utils.math import subtract_frame_transforms

from icecream import ic


##
# Pre-defined configs
##
from omni.isaac.lab_assets import FRANKA_PANDA_HIGH_PD_CFG  # isort:skip


@configclass
class TableTopSceneCfg(InteractiveSceneCfg):
    """Configuration for a cart-pole scene."""

    # ground plane
    ground = AssetBaseCfg(
        prim_path="/World/defaultGroundPlane",
        spawn=sim_utils.GroundPlaneCfg(),
        init_state=AssetBaseCfg.InitialStateCfg(pos=(0.0, 0.0, 0.0)),
    )

    # lights
    dome_light = AssetBaseCfg(
        prim_path="/World/Light", spawn=sim_utils.DomeLightCfg(intensity=3000.0, color=(0.75, 0.75, 0.75))
    )


    # pose_marker1 = AssetBaseCfg(
    #     prim_path="{ENV_REGEX_NS}/PoseMarker1",
    #     spawn=XFormPrim(prim_path="/World/PoseMarker1", scale=(0.1, 0.1, 0.1)),
    # )

    # pose_marker2 = AssetBaseCfg(
    #     prim_path="{ENV_REGEX_NS}/PoseMarker2",
    #     spawn=XFormPrim(prim_path="/World/PoseMarker2", scale=(0.1, 0.1, 0.1)),
    # )
    tray = AssetBaseCfg(
        prim_path="{ENV_REGEX_NS}/Tray",
        spawn=sim_utils.CuboidCfg(size=(0.3, 0.3, 0.01)),
        init_state=AssetBaseCfg.InitialStateCfg(pos=(0.0, 0.0, 0.3)),
    )

    base = AssetBaseCfg(
        prim_path="{ENV_REGEX_NS}/Base",
        spawn=sim_utils.CuboidCfg(size=(0.1, 0.1, 0.3)),
        init_state=AssetBaseCfg.InitialStateCfg(pos=(0.0, 0.0, 0.15)),
    )

    # articulation
    robot1 = FRANKA_PANDA_HIGH_PD_CFG.replace(prim_path="{ENV_REGEX_NS}/Robot1")
    robot2 = FRANKA_PANDA_HIGH_PD_CFG.replace(prim_path="{ENV_REGEX_NS}/Robot2")

    robot1.init_state.pos = (0.0, 0.5, 0.0)
    robot2.init_state.pos = (0.0, -0.5, 0.0)



def run_simulator(sim: sim_utils.SimulationContext, scene: InteractiveScene):
    """Runs the simulation loop."""
    # Extract scene entities
    # note: we only do this here for readability.
    robot1 = scene["robot1"]
    robot2 = scene["robot2"]

    # Create controller
    diff_ik_cfg = DifferentialIKControllerCfg(command_type="pose", use_relative_mode=False, ik_method="dls")
    diff_ik_controller1 = DifferentialIKController(diff_ik_cfg, num_envs=scene.num_envs, device=sim.device)
    diff_ik_controller2 = DifferentialIKController(diff_ik_cfg, num_envs=scene.num_envs, device=sim.device)

    # Markers
    frame_marker_cfg = FRAME_MARKER_CFG.copy()
    frame_marker_cfg.markers["frame"].scale = (0.1, 0.1, 0.1)

    ee_marker1 = VisualizationMarkers(frame_marker_cfg.replace(prim_path="/Visuals/ee_current1"))
    goal_marker1 = VisualizationMarkers(frame_marker_cfg.replace(prim_path="/Visuals/ee_goal1"))

    ee_marker2 = VisualizationMarkers(frame_marker_cfg.replace(prim_path="/Visuals/ee_current2"))
    goal_marker2 = VisualizationMarkers(frame_marker_cfg.replace(prim_path="/Visuals/ee_goal2"))

    # Define goals for the arm
    ee_goals1 = [
        [0.5, 0.5, 0.7, 0.707, 0, 0.707, 0],
        [0.5, 0.7, 0.6, 0.707, 0.707, 0.0, 0.0],
        [0.5, 0.3, 0.5, 0.0, 1.0, 0.0, 0.0],
    ]
    ee_goals2 = [
        [0.5, -0.5, 0.7, 0.707, 0, 0.707, 0],
        [0.5, -0.7, 0.6, 0.707, 0.707, 0.0, 0.0],
        [0.5, -0.30, 0.5, 0.0, 1.0, 0.0, 0.0],
    ]
    ee_goals1 = torch.tensor(ee_goals1, device=sim.device)
    ee_goals2 = torch.tensor(ee_goals2, device=sim.device)

    # ee_goals1 = torch.concat(scene["pose_marker1"].get_world_pose()[0],scene["pose_marker1"].get_world_pose()[1],dim=1)
    # ee_goals2 = torch.concat(scene["pose_marker2"].get_world_pose()[0],scene["pose_marker2"].get_world_pose()[1],dim=1)

    # Track the given command
    current_goal_idx = 0
    # Create buffers to store actions
    ik_commands1 = torch.zeros(scene.num_envs, diff_ik_controller1.action_dim, device=robot1.device)
    ik_commands1[:] = ee_goals1[current_goal_idx]

    ik_commands2 = torch.zeros(scene.num_envs, diff_ik_controller2.action_dim, device=robot2.device)
    ik_commands2[:] = ee_goals2[current_goal_idx]

    # Specify robot-specific parameters
    robot1_entity_cfg = SceneEntityCfg("robot1", joint_names=["panda_joint.*"], body_names=["panda_hand"])
    robot2_entity_cfg = SceneEntityCfg("robot2", joint_names=["panda_joint.*"], body_names=["panda_hand"])
    # Resolving the scene entities
    robot1_entity_cfg.resolve(scene)
    robot2_entity_cfg.resolve(scene)
    # Obtain the frame index of the end-effector
    # For a fixed base robot, the frame index is one less than the body index. This is because
    # the root body is not included in the returned Jacobians.
    if robot1.is_fixed_base:
        ee_jacobi_idx1 = robot1_entity_cfg.body_ids[0] - 1
    else:
        ee_jacobi_idx1 = robot1_entity_cfg.body_ids[0]

    if robot2.is_fixed_base:
        ee_jacobi_idx2 = robot2_entity_cfg.body_ids[0] - 1
    else:
        ee_jacobi_idx2 = robot2_entity_cfg.body_ids[0]

    # Define simulation stepping
    sim_dt = sim.get_physics_dt()
    count = 0
    # Simulation loop
    while simulation_app.is_running():
        # reset
        if count % 150 == 0:
            # reset time
            count = 0
            # reset joint state
            joint_pos1 = robot1.data.default_joint_pos.clone()
            joint_vel1 = robot1.data.default_joint_vel.clone()
            robot1.write_joint_state_to_sim(joint_pos1, joint_vel1)
            robot1.reset()

            joint_pos2 = robot2.data.default_joint_pos.clone()
            joint_vel2 = robot2.data.default_joint_vel.clone()
            robot2.write_joint_state_to_sim(joint_pos2, joint_vel2)
            robot2.reset()

            # reset actions
            ik_commands1[:] = ee_goals1[current_goal_idx]
            ik_commands2[:] = ee_goals2[current_goal_idx]
            joint_pos_des1 = joint_pos1[:, robot1_entity_cfg.joint_ids].clone()
            joint_pos_des2 = joint_pos2[:, robot2_entity_cfg.joint_ids].clone()
            # reset controller
            diff_ik_controller1.reset()
            diff_ik_controller1.set_command(ik_commands1)

            diff_ik_controller2.reset()
            diff_ik_controller2.set_command(ik_commands2)

            # change goal
            current_goal_idx = (current_goal_idx + 1) % len(ee_goals1)
        else:
            # obtain quantities from simulation
            jacobian1 = robot1.root_physx_view.get_jacobians()[:, ee_jacobi_idx1, :, robot1_entity_cfg.joint_ids]
            ee_pose_w1 = robot1.data.body_state_w[:, robot1_entity_cfg.body_ids[0], 0:7]
            root_pose_w1 = robot1.data.root_state_w[:, 0:7]
            root_pose_w1[:, 0:3] -= torch.tensor((0.0, 0.5, 0.0), device=sim.device)
            joint_pos1 = robot1.data.joint_pos[:, robot1_entity_cfg.joint_ids]
            # compute frame in root frame
            ee_pos_b1, ee_quat_b1 = subtract_frame_transforms(
                root_pose_w1[:, 0:3], root_pose_w1[:, 3:7], ee_pose_w1[:, 0:3], ee_pose_w1[:, 3:7]
            )
            # compute the joint commands
            joint_pos_des1 = diff_ik_controller1.compute(ee_pos_b1, ee_quat_b1, jacobian1, joint_pos1)

            jacobian2 = robot2.root_physx_view.get_jacobians()[:, ee_jacobi_idx2, :, robot2_entity_cfg.joint_ids]
            ee_pose_w2 = robot2.data.body_state_w[:, robot2_entity_cfg.body_ids[0], 0:7]
            root_pose_w2 = robot2.data.root_state_w[:, 0:7]
            root_pose_w2[:, 0:3] -= torch.tensor((0.0, -0.5, 0.0), device=sim.device)
            joint_pos2 = robot2.data.joint_pos[:, robot2_entity_cfg.joint_ids]
            # compute frame in root frame
            ee_pos_b2, ee_quat_b2 = subtract_frame_transforms(
                root_pose_w2[:, 0:3], root_pose_w2[:, 3:7], ee_pose_w2[:, 0:3], ee_pose_w2[:, 3:7]
            )
            # compute the joint commands
            joint_pos_des2 = diff_ik_controller2.compute(ee_pos_b2, ee_quat_b2, jacobian2, joint_pos2)

        # apply actions
        robot1.set_joint_position_target(joint_pos_des1, joint_ids=robot1_entity_cfg.joint_ids)
        robot2.set_joint_position_target(joint_pos_des2, joint_ids=robot2_entity_cfg.joint_ids)
        scene.write_data_to_sim()
        # perform step
        sim.step()
        # update sim-time
        count += 1
        # update buffers
        scene.update(sim_dt)

        # obtain quantities from simulation
        ee_pose_w1 = robot1.data.body_state_w[:, robot1_entity_cfg.body_ids[0], 0:7]
        ee_pose_w2 = robot2.data.body_state_w[:, robot2_entity_cfg.body_ids[0], 0:7]
        # update marker positions
        ee_marker1.visualize(ee_pose_w1[:, 0:3], ee_pose_w1[:, 3:7])
        goal_marker1.visualize(ik_commands1[:, 0:3] + scene.env_origins, ik_commands1[:, 3:7])

        ee_marker2.visualize(ee_pose_w2[:, 0:3], ee_pose_w2[:, 3:7])
        goal_marker2.visualize(ik_commands2[:, 0:3] + scene.env_origins, ik_commands2[:, 3:7])



def main():
    """Main function."""
    # Load kit helper
    sim_cfg = sim_utils.SimulationCfg(dt=0.01, device=args_cli.device)
    sim = sim_utils.SimulationContext(sim_cfg)
    # Set main camera
    sim.set_camera_view([2.5, 2.5, 2.5], [0.0, 0.0, 0.0])
    # Design scene
    scene_cfg = TableTopSceneCfg(num_envs=args_cli.num_envs, env_spacing=2.0)
    scene = InteractiveScene(scene_cfg)
    # Play the simulator
    sim.reset()
    # Now we are ready!
    print("[INFO]: Setup complete...")
    # Run the simulator
    run_simulator(sim, scene)


if __name__ == "__main__":
    # run the main function
    main()
    # close sim app
    simulation_app.close()
